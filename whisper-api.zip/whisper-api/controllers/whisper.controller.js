const Whisper = require('../models/whisper.model');

// Controlador para crear susurro
exports.createWhisper = async (req, res) => {
  try {
    const { sender_id, receiver_id, message, game_id } = req.body;
    const whisperId = await Whisper.create({ sender_id, receiver_id, message, game_id });
    res.status(201).json({ id: whisperId, message: 'Susurro creado exitosamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error al crear susurro' });
  }
};

// Controlador para obtener todos los susurros
exports.getAllWhispers = async (req, res) => {
  try {
    const whispers = await Whisper.getAll();
    res.json(whispers);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener susurros' });
  }
};

// Controlador para obtener un susurro por ID
exports.getWhisperById = async (req, res) => {
  try {
    const whisper = await Whisper.getById(req.params.id);
    whisper 
      ? res.json(whisper) 
      : res.status(404).json({ error: 'Susurro no encontrado' });
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener susurro' });
  }
};

// Controlador para actualizar un susurro
exports.updateWhisper = async (req, res) => {
  try {
    await Whisper.update(req.params.id, req.body);
    res.json({ message: 'Susurro actualizado exitosamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error al actualizar susurro' });
  }
};

// Controlador para eliminar un susurro
exports.deleteWhisper = async (req, res) => {
  try {
    await Whisper.delete(req.params.id);
    res.json({ message: 'Susurro eliminado exitosamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar susurro' });
  }
};