CREATE DATABASE IF NOT EXISTS whisper_db;
USE whisper_db;

CREATE TABLE whispers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sender_id INT NOT NULL,
  receiver_id INT NOT NULL,
  message TEXT NOT NULL,
  game_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Datos de ejemplo
INSERT INTO whispers (sender_id, receiver_id, message, game_id) VALUES
(1, 2, '¿Jugamos esta noche?', 101),
(2, 1, 'Claro, a las 8 PM', 101),
(3, 1, 'Necesito ayuda en nivel 5', 102);