const db = require('../config/db');

class Whisper {
  // Crear un nuevo susurro
  static async create({ sender_id, receiver_id, message, game_id }) {
    const [result] = await db.execute(
      'INSERT INTO whispers (sender_id, receiver_id, message, game_id) VALUES (?, ?, ?, ?)',
      [sender_id, receiver_id, message, game_id]
    );
    return result.insertId;
  }

  // Obtener todos los susurros
  static async getAll() {
    const [rows] = await db.query('SELECT * FROM whispers');
    return rows;
  }

  // Obtener susurro por ID
  static async getById(id) {
    const [rows] = await db.execute('SELECT * FROM whispers WHERE id = ?', [id]);
    return rows[0];
  }

  // Actualizar un susurro
  static async update(id, { message }) {
    await db.execute(
      'UPDATE whispers SET message = ? WHERE id = ?',
      [message, id]
    );
  }

  // Eliminar un susurro
  static async delete(id) {
    await db.execute('DELETE FROM whispers WHERE id = ?', [id]);
  }
}

module.exports = Whisper;