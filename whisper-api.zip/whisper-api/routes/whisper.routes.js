const express = require('express');
const router = express.Router();
const whisperController = require('../controllers/whisper.controller');

// CRUD para susurros
router.post('/', whisperController.createWhisper);
router.get('/', whisperController.getAllWhispers);
router.get('/:id', whisperController.getWhisperById);
router.put('/:id', whisperController.updateWhisper);
router.delete('/:id', whisperController.deleteWhisper);

module.exports = router;